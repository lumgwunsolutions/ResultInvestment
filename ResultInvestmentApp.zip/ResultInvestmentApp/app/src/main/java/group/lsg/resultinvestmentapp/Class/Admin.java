package group.lsg.resultinvestmentapp.Class;

public class Admin extends User {

    public Admin(String lastName, String firstNames,
                 String email,String phone) {
        super(lastName, firstNames, email,phone);
    }

}
