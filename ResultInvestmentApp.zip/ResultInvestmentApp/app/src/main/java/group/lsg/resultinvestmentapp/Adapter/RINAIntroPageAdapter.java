package group.lsg.resultinvestmentapp.Adapter;

public class RINAIntroPageAdapter {
}
