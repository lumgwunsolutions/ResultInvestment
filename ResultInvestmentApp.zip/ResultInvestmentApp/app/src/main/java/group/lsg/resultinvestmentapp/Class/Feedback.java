package group.lsg.resultinvestmentapp.Class;

public class Feedback extends BmobObject {

    String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}




