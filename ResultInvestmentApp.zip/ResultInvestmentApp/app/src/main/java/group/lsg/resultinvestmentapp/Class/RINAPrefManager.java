package group.lsg.resultinvestmentapp.Class;

public class RINAPrefManager {
}
