package group.lsg.resultinvestmentapp.Class;

public class RINA {
    public static String APPLICATION_ID = "//9d30e7692a56a79d7600b95cbff43283";
}
