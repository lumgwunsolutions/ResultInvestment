package group.lsg.resultinvestmentapp.Class;

public interface LazyLoading {
    ItemType getItemType();
    void setItemType(ItemType itemType);
}



