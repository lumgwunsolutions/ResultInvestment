package group.lsg.resultinvestmentapp.Class;

public interface GuillotineListener {
    void onGuillotineOpened();
    void onGuillotineClosed();
}