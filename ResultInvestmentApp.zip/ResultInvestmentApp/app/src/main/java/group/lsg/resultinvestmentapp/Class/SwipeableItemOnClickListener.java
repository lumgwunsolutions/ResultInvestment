package group.lsg.resultinvestmentapp.Class;

import android.view.View;

public class SwipeableItemOnClickListener implements View.OnClickListener {

    private int position;

    public SwipeableItemOnClickListener() {
    }

    public SwipeableItemOnClickListener(int position) {
        this.position = position;
    }

    @Override
    public void onClick(View v) {

    }
}
