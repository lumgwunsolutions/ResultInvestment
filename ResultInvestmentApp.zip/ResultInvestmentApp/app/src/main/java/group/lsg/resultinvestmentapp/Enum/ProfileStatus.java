package group.lsg.resultinvestmentapp.Enum;

public enum ProfileStatus {
}
